/* fonts */
export const FontFamily = {
  museoModernoBold: "MuseoModerno-Bold",
  josefinSansRegular: "JosefinSans-Regular",
  muktaRegular: "Mukta-Regular",
  latoBold: "Lato-Bold",
  leagueSpartanSemiBold: "LeagueSpartan-SemiBold",
  robotoRegular: "Roboto-Regular",
  robotoBold: "Roboto-Bold",
  abelRegular: "Abel-Regular",
  josefinSansBold: "JosefinSans-Bold",
};
/* font sizes */
export const FontSize = {
  size_5xl: 24,
  size_29xl: 48,
  size_3xl: 22,
  size_sm: 14,
  size_7xl: 26,
  size_base: 16,
  size_13xl: 32,
  size_mini: 15,
};
/* Colors */
export const Color = {
  blackBlack100: "#fff",
  blackBlack3: "#03060e",
  sienna: "#946d42",
  yellowgreen: "#8dc73f",
  black: "#000",
  gray1: "#333",
};
/* border radiuses */
export const Border = {
  br_3xs: 10,
  br_base: 16,
};
