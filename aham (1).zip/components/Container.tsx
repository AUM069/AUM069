import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import Button1 from "./Button1";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const Container = () => {
  return (
    <View style={[styles.buttonParent, styles.text1Layout]}>
      <Button1
        pageTitle="MARKET RATES AND UPDATES"
        showText={false}
        buttonPosition="absolute"
        buttonBorderRadius={16}
        buttonBackgroundColor="#8dc73f"
        buttonWidth={100}
        buttonHeight={100}
        buttonTop={0}
        buttonLeft={0}
        buttonElevation={10}
        textFontSize={22}
        textFontWeight="unset"
        textFontFamily="Mukta-Regular"
        textWidth={60}
      />
      <Image
        style={[styles.storeIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/store.png")}
      />
      <Image
        style={[styles.marketAnalysisIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/market-analysis.png")}
      />
      <Image
        style={styles.groupChild}
        contentFit="cover"
        source={require("../assets/vector-1.png")}
      />
      <Text style={[styles.text, styles.textFlexBox]}>₹</Text>
      <Text style={[styles.text1, styles.textFlexBox]}>
        Market Rates and Updates
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  text1Layout: {
    width: 100,
    left: 0,
  },
  iconLayout: {
    height: 80,
    width: 80,
    position: "absolute",
  },
  textFlexBox: {
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    fontWeight: "600",
    textTransform: "capitalize",
    lineHeight: 18,
    position: "absolute",
  },
  storeIcon: {
    top: 617,
    left: 26,
    display: "none",
  },
  marketAnalysisIcon: {
    top: 12,
    left: 10,
  },
  groupChild: {
    top: 15,
    left: 72,
    width: 12,
    height: 17,
    position: "absolute",
  },
  text: {
    top: 18,
    left: 73,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.leagueSpartanSemiBold,
    color: Color.black,
    width: 9,
    height: 15,
  },
  text1: {
    marginTop: 34.5,
    top: "50%",
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.latoBold,
    color: Color.blackBlack3,
    height: 40,
    width: 100,
    left: 0,
  },
  buttonParent: {
    top: 0,
    height: 149,
    position: "absolute",
  },
});

export default Container;
