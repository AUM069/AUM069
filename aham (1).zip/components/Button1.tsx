import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

type Button1Type = {
  pageTitle?: string;
  showText?: boolean;

  /** Style props */
  buttonPosition?: string;
  buttonBorderRadius?: number;
  buttonBackgroundColor?: string;
  buttonWidth?: number | string;
  buttonHeight?: number | string;
  buttonTop?: number | string;
  buttonLeft?: number | string;
  buttonElevation?: number;
  textFontSize?: number;
  textFontWeight?: string;
  textFontFamily?: string;
  textWidth?: number | string;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Button1 = ({
  pageTitle,
  showText,
  buttonPosition,
  buttonBorderRadius,
  buttonBackgroundColor,
  buttonWidth,
  buttonHeight,
  buttonTop,
  buttonLeft,
  buttonElevation,
  textFontSize,
  textFontWeight,
  textFontFamily,
  textWidth,
}: Button1Type) => {
  const buttonStyle = useMemo(() => {
    return {
      ...getStyleValue("position", buttonPosition),
      ...getStyleValue("borderRadius", buttonBorderRadius),
      ...getStyleValue("backgroundColor", buttonBackgroundColor),
      ...getStyleValue("width", buttonWidth),
      ...getStyleValue("height", buttonHeight),
      ...getStyleValue("top", buttonTop),
      ...getStyleValue("left", buttonLeft),
      ...getStyleValue("elevation", buttonElevation),
    };
  }, [
    buttonPosition,
    buttonBorderRadius,
    buttonBackgroundColor,
    buttonWidth,
    buttonHeight,
    buttonTop,
    buttonLeft,
    buttonElevation,
  ]);

  const textStyle = useMemo(() => {
    return {
      ...getStyleValue("fontSize", textFontSize),
      ...getStyleValue("fontWeight", textFontWeight),
      ...getStyleValue("fontFamily", textFontFamily),
      ...getStyleValue("width", textWidth),
    };
  }, [textFontSize, textFontWeight, textFontFamily, textWidth]);

  return (
    <View style={[styles.button, buttonStyle]}>
      {showText && <Text style={[styles.text, textStyle]}>{pageTitle}</Text>}
    </View>
  );
};

const styles = StyleSheet.create({
  text: {
    position: "absolute",
    marginTop: -19,
    top: "50%",
    left: 20,
    fontSize: FontSize.size_5xl,
    fontWeight: "700",
    fontFamily: FontFamily.museoModernoBold,
    color: Color.blackBlack3,
    textAlign: "center",
    width: 288,
  },
  button: {
    borderRadius: 20,
    backgroundColor: Color.blackBlack100,
    width: 328,
    height: 80,
  },
});

export default Button1;
