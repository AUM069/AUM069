import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import Button1 from "./Button1";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const Container1 = () => {
  return (
    <View style={styles.textParent}>
      <Text style={[styles.text, styles.textFlexBox]}>Financial Services</Text>
      <Button1
        pageTitle="MARKET RATES AND UPDATES"
        showText={false}
        buttonPosition="absolute"
        buttonBorderRadius={16}
        buttonBackgroundColor="#8dc73f"
        buttonWidth={100}
        buttonHeight={100}
        buttonTop={0}
        buttonLeft={0}
        buttonElevation={10}
        textFontSize={22}
        textFontWeight="unset"
        textFontFamily="Mukta-Regular"
        textWidth={60}
      />
      <Image
        style={styles.moneyIcon}
        contentFit="cover"
        source={require("../assets/money.png")}
      />
      <Image
        style={styles.groupChild}
        contentFit="cover"
        source={require("../assets/vector-11.png")}
      />
      <Text style={[styles.text1, styles.textFlexBox]}>₹</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  textFlexBox: {
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    textAlign: "center",
    fontWeight: "600",
    textTransform: "capitalize",
    lineHeight: 18,
    position: "absolute",
  },
  text: {
    marginTop: 34.5,
    left: 0,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.latoBold,
    color: Color.blackBlack3,
    width: 100,
    height: 40,
    top: "50%",
  },
  moneyIcon: {
    top: 10,
    left: 10,
    width: 80,
    height: 80,
    position: "absolute",
  },
  groupChild: {
    top: 47,
    left: 54,
    width: 22,
    height: 32,
    position: "absolute",
  },
  text1: {
    top: 55,
    left: 56,
    fontSize: FontSize.size_7xl,
    fontFamily: FontFamily.leagueSpartanSemiBold,
    color: Color.black,
    width: 16,
    height: 23,
  },
  textParent: {
    marginTop: -74.5,
    right: 121,
    left: 122,
    height: 149,
    top: "50%",
    position: "absolute",
  },
});

export default Container1;
