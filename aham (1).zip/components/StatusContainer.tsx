import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const StatusContainer = () => {
  return (
    <View style={[styles.statusBar, styles.statusPosition]}>
      <Image
        style={[styles.statusBarChild, styles.batteryIconLayout]}
        contentFit="cover"
        source={require("../assets/rectangle-21.png")}
      />
      <Image
        style={[styles.batteryIcon, styles.batteryIconLayout]}
        contentFit="cover"
        source={require("../assets/battery.png")}
      />
      <Image
        style={styles.wifiIcon}
        contentFit="cover"
        source={require("../assets/wifi.png")}
      />
      <Image
        style={styles.mobileSignalIcon}
        contentFit="cover"
        source={require("../assets/mobile-signal.png")}
      />
      <View style={[styles.timeStyle, styles.textPosition]}>
        <Text style={[styles.text, styles.textPosition]}>9:41</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  statusPosition: {
    left: "0%",
    right: "0%",
    top: "0%",
    width: "100%",
  },
  batteryIconLayout: {
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  textPosition: {
    top: "50%",
    position: "absolute",
  },
  statusBarChild: {
    height: "100%",
    bottom: "0%",
    left: "0%",
    right: "0%",
    top: "0%",
    width: "100%",
  },
  batteryIcon: {
    height: "25.76%",
    width: "6.49%",
    top: "39.39%",
    right: "3.91%",
    bottom: "34.85%",
    left: "89.6%",
  },
  wifiIcon: {
    width: 15,
    height: 11,
  },
  mobileSignalIcon: {
    width: 17,
    height: 11,
  },
  text: {
    marginTop: -10,
    left: 0,
    fontSize: FontSize.size_mini,
    letterSpacing: 0,
    fontFamily: FontFamily.abelRegular,
    color: Color.gray1,
    textAlign: "left",
    width: 54,
  },
  timeStyle: {
    marginTop: -8,
    right: 300,
    left: 21,
    height: 20,
  },
  statusBar: {
    height: "5.42%",
    bottom: "94.58%",
    position: "absolute",
    left: "0%",
    right: "0%",
    top: "0%",
    width: "100%",
  },
});

export default StatusContainer;
