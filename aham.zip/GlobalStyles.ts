/* fonts */
export const FontFamily = {
  josefinSansBold: "JosefinSans-Bold",
  josefinSansRegular: "JosefinSans-Regular",
  abelRegular: "Abel-Regular",
};
/* font sizes */
export const FontSize = {
  size_29xl: 48,
};
/* Colors */
export const Color = {
  gray1: "#333",
};
